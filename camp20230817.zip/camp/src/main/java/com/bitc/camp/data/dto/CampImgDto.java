package com.bitc.camp.data.dto;

import com.bitc.camp.data.entity.CampMainInfo;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
public class CampImgDto {
    private int idx;
    private String originalFileName;
    private String storedFileName;
    private int fileSize;
    private CampMainInfo campMainInfo;
}
