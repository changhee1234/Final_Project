package com.bitc.camp.data.dto;

import com.bitc.camp.data.entity.CampMainInfo;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Builder
@Data
public class CampSiteInfoDto {
    private int idx;
    private String areaName;
    private int sitePrice;
    private String notice;
    private String CampStyle;
    private int peopleMin;
    private int peopleMax;
    private int addPrice;
    private int campReservePeriod;
    private int parkPrice;
    private int elePrice;
    private int areaSiteCnt;
    private CampMainInfo campMainInfo;
}
