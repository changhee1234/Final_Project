package com.bitc.camp.data.dto;

import com.bitc.camp.data.entity.CampMainInfo;
import com.bitc.camp.data.entity.Member;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
public class ReviewBoardDto {
    private int idx;
    private String reContent;
    private CampMainInfo campMainInfo;
    private Member member;
    private String nickName;
}
