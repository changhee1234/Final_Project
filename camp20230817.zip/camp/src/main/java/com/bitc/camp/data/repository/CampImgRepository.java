package com.bitc.camp.data.repository;

import com.bitc.camp.data.entity.CampImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CampImgRepository extends JpaRepository<CampImg, Integer> {
}
