package com.bitc.camp.data.repository;

import com.bitc.camp.data.entity.CampSiteList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CampSiteListRepository extends JpaRepository<CampSiteList, Integer> {
}
