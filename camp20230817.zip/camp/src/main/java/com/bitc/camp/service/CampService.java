package com.bitc.camp.service;

import com.bitc.camp.data.dto.*;
import com.bitc.camp.data.entity.CampMainInfo;
import com.bitc.camp.data.entity.CampSiteInfo;
import com.bitc.camp.data.entity.CampSiteList;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface CampService {
    List<CampMainInfoDto> selectCampList() throws Exception;

    List<ReviewBoardDto> selectReviewList(CampMainInfo campMainInfo) throws Exception;

    CampMainInfo createCamp(CampMainInfoDto campMainInfoDto) throws Exception;

    List<CampSiteInfo> createCamp2(List<CampSiteInfoDto> campSiteInfoDtoList) throws Exception;
}
