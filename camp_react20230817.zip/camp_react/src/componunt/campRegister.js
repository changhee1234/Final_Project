import React, {useState} from "react";
import axios from "axios";

function CampRegister(props) {
    const [campName, setCampName] = useState('');
    const [campIntro, setCampIntro] = useState('');
    const [campDt, setCampDt] = useState(new Date());
    const [kidszoneYn, setKiszoneYn] = useState('');
    const [campHpLink, setCampHpKink] = useState('');
    const [campPh, setCampPh] = useState('');
    const [campAddress, setCampAddress] = useState('');
    const [partner, setPartner] = useState({idx: 0,});

    const campRegisterHandler = (e) => {
        e.preventDefault();

        const campData = {
            campName,
            campIntro,
            campDt: campDt.toISOString().substr(0, 16),
            kidszoneYn,
            campHpLink,
            campPh,
            campAddress,
            partner
        };

        axios.post('http://localhost:8080/campRegister',campData, {
            headers: {
                'Content-Type' : 'application/json'
            }
        })
            .then((res) => {
                console.log(res.data);
            })
            .catch((err) => {
                console.log(err);
            })
    }

    return (
        <div className={'col-sm-4 mx-auto text-start'}>
            <form onSubmit={campRegisterHandler}>

                <input
                    className={'form-control'}
                    id={'campDt'}
                    type="hidden"
                    value={campDt.toISOString().substr(0, 16)}
                    onChange={(e) => setCampDt(new Date(e.target.value))}/>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'campName'}>캠핑장명 : </label>
                    <input className={'form-control'} id={'campName'} value={campName}
                           onChange={(e) => setCampName(e.target.value)}/>
                </div>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'campIntro'}>캠핑장설명 : </label>
                    <input className={'form-control'} id={'campIntro'} value={campIntro}
                           onChange={(e) => setCampIntro(e.target.value)}/>
                </div>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'kidsZoneYn'}>키즈존 여부 : </label>
                    <input className={'form-control'} id={'kidsZoneYn'} value={kidszoneYn}
                           onChange={(e) => setKiszoneYn(e.target.value)}/>
                </div>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'campHpLink'}>홈페이지 : </label>
                    <input className={'form-control'} id={'campHpLink'} value={campHpLink}
                           onChange={(e) => setCampHpKink(e.target.value)}/>
                </div>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'campPh'}>전화번호 : </label>
                    <input className={'form-control'} id={'campPh'} value={campPh}
                           onChange={(e) => setCampPh(e.target.value)}/>
                </div>

                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'campAddress'}>주소 : </label>
                    <input className={'form-control'} id={'campAddress'} value={campAddress}
                           onChange={(e) => setCampAddress(e.target.value)}/>
                </div>
                <div className={'my-3'}>
                    <label className={'form-label'} htmlFor={'partner'}>회원번호 : </label>
                    <input className={'form-control'} id={'partner'} value={partner.idx}
                           onChange={(e) => setPartner({ ...partner, idx: e.target.value })}/>
                </div>
                <button className={'btn btn-primary'} type="submit">Register Camp</button>
            </form>
        </div>
    );
}

export default CampRegister;