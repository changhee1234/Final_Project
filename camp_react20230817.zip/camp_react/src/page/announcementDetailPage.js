import React from "react";

function AnnouncementDetailPage(props) {
    return (
        <main className={'container'}>
            <h1 className={'text-center'}>announcementDetail.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default AnnouncementDetailPage;