import React from "react";


function AnnouncementListPage(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>announcementListPage.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default AnnouncementListPage;