import React from "react";


function CampDetailPage(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>campDetailPage.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default CampDetailPage;