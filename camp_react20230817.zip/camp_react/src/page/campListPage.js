import React from "react";
import CampList from "../componunt/jeongGyuHo/campList";


function CampListPage(props) {

    return (
        <main className={"container-fluid"}>
            <CampList/>
        </main>
    );
}

export default CampListPage;