import React from "react";


function CampReservationPage1(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>campReservationPage1.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default CampReservationPage1;