import React from "react";


function CampReservationPage2(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>campReservationPage2.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default CampReservationPage2;