import React from "react";


function CampReservationPage3(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>campReservationPage3.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default CampReservationPage3;