import React from "react";

function ErrorPage(props) {

    return (
        <div className={'container'}>
            <h1 className={'text-center'}>Error</h1>
        </div>
    );
}

export default ErrorPage;