import React from "react";
import MainCarousel from "../componunt/main/mainCarousel";
import CampRegister from "../componunt/campRegister";
import CampRegister2 from "../componunt/campRegister2";







function MainPage(props) {

    return (
        <main className={"container"}>
            {/*<MainCarousel/>*/}
            {/*<CampRegister/>*/}
            <CampRegister2/>
        </main>
    );
}

export default MainPage;