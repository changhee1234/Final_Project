import React from "react";


function MyPage(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>myPage.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default MyPage;