import React from "react";


function TradeDetailPage(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>tradeDetailPage.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default TradeDetailPage;