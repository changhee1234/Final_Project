import React from "react";


function TradeListPage(props) {

    return (
        <main className={"container"}>
            <h1 className={'text-center'}>tradeListPage.js</h1>
            <h1 className={'text-center'}>test</h1>
        </main>
    );
}

export default TradeListPage;